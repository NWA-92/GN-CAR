// Serveur temps réel : passagers <-> chauffeurs (données en mémoire, à remplacer par une base de données)
const express = require('express');
const http = require('http');
const cors = require('cors');
const { Server } = require('socket.io');

const app = express();
app.use(cors());
app.use(express.json());
const server = http.createServer(app);
const io = new Server(server, { cors: { origin: '*' } });

const rides = new Map();
let nextId = 1;

// --- Tarification -----------------------------------------------------------
const toRad = (d) => (d * Math.PI) / 180;
function distanceKm(a, b) {
  const R = 6371;
  const dLat = toRad(b.latitude - a.latitude);
  const dLon = toRad(b.longitude - a.longitude);
  const x =
    Math.sin(dLat / 2) ** 2 +
    Math.cos(toRad(a.latitude)) * Math.cos(toRad(b.latitude)) * Math.sin(dLon / 2) ** 2;
  return 2 * R * Math.asin(Math.sqrt(x)) * 1.3; // 1,3 = coefficient route vs vol d'oiseau
}
function computeFare(km) {
  const minutes = (km / 30) * 60; // vitesse moyenne 30 km/h
  return Math.max(5, +(2.5 + 1.1 * km + 0.3 * minutes).toFixed(2));
}

const openRides = () => [...rides.values()].filter((r) => r.status === 'searching');
const broadcastOpen = () => io.to('drivers').emit('rides:open', openRides());

app.post('/api/estimate', (req, res) => {
  const { pickup, dropoff } = req.body;
  const km = distanceKm(pickup, dropoff);
  res.json({ km: +km.toFixed(1), price: computeFare(km) });
});

// --- Temps réel -------------------------------------------------------------
io.on('connection', (socket) => {
  socket.on('driver:online', () => {
    socket.join('drivers');
    socket.emit('rides:open', openRides());
  });
  socket.on('driver:offline', () => socket.leave('drivers'));

  socket.on('ride:request', ({ pickup, dropoff }, cb) => {
    const km = distanceKm(pickup, dropoff);
    const ride = {
      id: String(nextId++),
      pickup,
      dropoff,
      km: +km.toFixed(1),
      price: computeFare(km),
      status: 'searching',
      passengerSocket: socket.id,
      driverSocket: null,
    };
    rides.set(ride.id, ride);
    socket.join(`ride:${ride.id}`);
    cb?.({ ok: true, ride });
    broadcastOpen();
  });

  socket.on('ride:accept', ({ id }, cb) => {
    const ride = rides.get(id);
    if (!ride || ride.status !== 'searching') return cb?.({ ok: false, error: 'Course déjà prise' });
    ride.status = 'accepted';
    ride.driverSocket = socket.id;
    socket.join(`ride:${id}`);
    cb?.({ ok: true, ride });
    io.to(`ride:${id}`).emit('ride:update', ride);
    broadcastOpen();
  });

  socket.on('ride:status', ({ id, status }) => {
    const ride = rides.get(id);
    if (!ride) return;
    const allowed = ['ongoing', 'completed', 'cancelled'];
    if (!allowed.includes(status)) return;
    ride.status = status;
    io.to(`ride:${id}`).emit('ride:update', ride);
    broadcastOpen();
  });

  socket.on('driver:location', ({ id, coords }) => {
    io.to(`ride:${id}`).emit('ride:driver_location', coords);
  });

  socket.on('disconnect', () => {
    for (const ride of rides.values()) {
      if (ride.passengerSocket === socket.id && ['searching', 'accepted'].includes(ride.status)) {
        ride.status = 'cancelled';
        io.to(`ride:${ride.id}`).emit('ride:update', ride);
      }
    }
    broadcastOpen();
  });
});

const PORT = process.env.PORT || 3000;
server.listen(PORT, () => console.log(`Serveur prêt sur le port ${PORT}`));
