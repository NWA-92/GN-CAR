# Application de transport (VTC / covoiturage) — React Native + Node.js

## 1. Serveur
```bash
cd serveur
npm install
npm start          # écoute sur le port 3000
```

## 2. Application mobile (Expo)
```bash
npx create-expo-app@latest mobile-app
cd mobile-app
npx expo install react-native-maps expo-location
npm install socket.io-client
```
Remplace ensuite `App.js` et ajoute `config.js` (dossier `mobile/`), puis mets l'adresse IP
locale de ton ordinateur dans `config.js`.
```bash
npx expo start
```
Scanne le QR code avec Expo Go. Pour tester : un téléphone en mode **Passager**,
un autre (ou un émulateur) en mode **Chauffeur**.

## Fonctionnement
- Passager : touche la carte pour fixer la destination → prix estimé → « Commander une course ».
- Chauffeur : « Se mettre en ligne » → « Accepter » → « Démarrer » → « Terminer ».
- Position du chauffeur envoyée en temps réel (Socket.IO).

## Étapes suivantes pour la production
Authentification (comptes passager/chauffeur), base de données (PostgreSQL + PostGIS),
paiement (Stripe), itinéraires réels (Google Directions / Mapbox), notifications push,
et clé API Google Maps pour Android.
