// Remplace par l'adresse IP locale de ton ordinateur (ex. http://192.168.1.20:3000)
export const SERVER_URL = 'http://192.168.1.20:3000';
