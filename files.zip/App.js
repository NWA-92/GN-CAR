import React, { useEffect, useRef, useState } from 'react';
import { View, Text, StyleSheet, Pressable, SafeAreaView, Alert } from 'react-native';
import MapView, { Marker, Polyline } from 'react-native-maps';
import * as Location from 'expo-location';
import { io } from 'socket.io-client';
import { SERVER_URL } from './config';

const C = { ink: '#14202B', bg: '#F5F7FA', accent: '#0E7C86', amber: '#F2A900', line: '#D9E0E7', danger: '#C2410C' };

const STATUS_LABEL = {
  searching: 'Recherche d’un chauffeur…',
  accepted: 'Chauffeur en route',
  ongoing: 'Course en cours',
  completed: 'Course terminée',
  cancelled: 'Course annulée',
};

export default function App() {
  const [role, setRole] = useState('passenger');
  const [me, setMe] = useState(null);
  const [dropoff, setDropoff] = useState(null);
  const [ride, setRide] = useState(null);
  const [open, setOpen] = useState([]);
  const [online, setOnline] = useState(false);
  const [driverPos, setDriverPos] = useState(null);
  const socket = useRef(null);
  const watcher = useRef(null);
  const rideRef = useRef(null);
  rideRef.current = ride;

  useEffect(() => {
    (async () => {
      const { status } = await Location.requestForegroundPermissionsAsync();
      if (status !== 'granted') return Alert.alert('Localisation refusée', 'Active la localisation pour utiliser l’application.');
      const pos = await Location.getCurrentPositionAsync({});
      setMe({ latitude: pos.coords.latitude, longitude: pos.coords.longitude });
    })();

    const s = io(SERVER_URL, { transports: ['websocket'] });
    socket.current = s;
    s.on('rides:open', setOpen);
    s.on('ride:update', (r) => {
      if (rideRef.current?.id === r.id) setRide(r);
      if (['completed', 'cancelled'].includes(r.status)) stopSharing();
    });
    s.on('ride:driver_location', setDriverPos);
    return () => {
      stopSharing();
      s.disconnect();
    };
  }, []);

  const stopSharing = () => {
    watcher.current?.remove();
    watcher.current = null;
  };

  // --- Passager ---
  const requestRide = () => {
    if (!me || !dropoff) return;
    socket.current.emit('ride:request', { pickup: me, dropoff }, (res) => res.ok && setRide(res.ride));
  };
  const setStatus = (status) => socket.current.emit('ride:status', { id: ride.id, status });
  const reset = () => {
    setRide(null);
    setDropoff(null);
    setDriverPos(null);
  };

  // --- Chauffeur ---
  const toggleOnline = () => {
    socket.current.emit(online ? 'driver:offline' : 'driver:online');
    setOnline(!online);
    if (online) setOpen([]);
  };
  const accept = (id) =>
    socket.current.emit('ride:accept', { id }, async (res) => {
      if (!res.ok) return Alert.alert(res.error);
      setRide(res.ride);
      watcher.current = await Location.watchPositionAsync({ distanceInterval: 10 }, (p) =>
        socket.current.emit('driver:location', {
          id: res.ride.id,
          coords: { latitude: p.coords.latitude, longitude: p.coords.longitude },
        })
      );
    });

  const active = ride && !['completed', 'cancelled'].includes(ride.status);
  const target = ride?.dropoff || dropoff;
  const pickup = ride?.pickup || me;

  return (
    <SafeAreaView style={styles.root}>
      <View style={styles.tabs}>
        {['passenger', 'driver'].map((r) => (
          <Pressable key={r} disabled={active} onPress={() => setRole(r)} style={[styles.tab, role === r && styles.tabOn]}>
            <Text style={[styles.tabTxt, role === r && styles.tabTxtOn]}>{r === 'passenger' ? 'Passager' : 'Chauffeur'}</Text>
          </Pressable>
        ))}
      </View>

      <MapView
        style={styles.map}
        showsUserLocation
        region={me && { ...me, latitudeDelta: 0.03, longitudeDelta: 0.03 }}
        onPress={(e) => role === 'passenger' && !ride && setDropoff(e.nativeEvent.coordinate)}
      >
        {pickup && target && <Polyline coordinates={[pickup, target]} strokeColor={C.accent} strokeWidth={4} />}
        {target && <Marker coordinate={target} title="Destination" pinColor={C.amber} />}
        {driverPos && <Marker coordinate={driverPos} title="Chauffeur" pinColor={C.ink} />}
        {role === 'driver' && !ride && open.map((r) => <Marker key={r.id} coordinate={r.pickup} title={`${r.price} €`} />)}
      </MapView>

      <View style={styles.sheet}>
        {role === 'passenger' ? (
          <Passenger {...{ ride, dropoff, requestRide, setStatus, reset }} />
        ) : (
          <Driver {...{ ride, online, open, toggleOnline, accept, setStatus, reset }} />
        )}
      </View>
    </SafeAreaView>
  );
}

function Btn({ label, onPress, kind = 'primary', disabled }) {
  return (
    <Pressable
      onPress={onPress}
      disabled={disabled}
      style={[styles.btn, kind === 'ghost' && styles.btnGhost, disabled && { opacity: 0.4 }]}
    >
      <Text style={[styles.btnTxt, kind === 'ghost' && { color: C.danger }]}>{label}</Text>
    </Pressable>
  );
}

function Passenger({ ride, dropoff, requestRide, setStatus, reset }) {
  if (!ride)
    return (
      <>
        <Text style={styles.title}>{dropoff ? 'Destination choisie' : 'Où allez-vous ?'}</Text>
        <Text style={styles.sub}>{dropoff ? 'Vous pouvez la déplacer en touchant la carte.' : 'Touchez la carte pour choisir votre destination.'}</Text>
        <Btn label="Commander une course" onPress={requestRide} disabled={!dropoff} />
      </>
    );
  const done = ['completed', 'cancelled'].includes(ride.status);
  return (
    <>
      <Text style={styles.title}>{STATUS_LABEL[ride.status]}</Text>
      <Text style={styles.sub}>{ride.km} km · {ride.price} €</Text>
      {done ? (
        <Btn label="Nouvelle course" onPress={reset} />
      ) : (
        ride.status !== 'ongoing' && <Btn kind="ghost" label="Annuler la course" onPress={() => setStatus('cancelled')} />
      )}
    </>
  );
}

function Driver({ ride, online, open, toggleOnline, accept, setStatus, reset }) {
  if (ride) {
    const done = ['completed', 'cancelled'].includes(ride.status);
    return (
      <>
        <Text style={styles.title}>{STATUS_LABEL[ride.status]}</Text>
        <Text style={styles.sub}>{ride.km} km · {ride.price} €</Text>
        {ride.status === 'accepted' && <Btn label="Démarrer la course" onPress={() => setStatus('ongoing')} />}
        {ride.status === 'ongoing' && <Btn label="Terminer la course" onPress={() => setStatus('completed')} />}
        {done && <Btn label="Retour" onPress={reset} />}
      </>
    );
  }
  return (
    <>
      <Text style={styles.title}>{online ? `${open.length} course(s) disponible(s)` : 'Vous êtes hors ligne'}</Text>
      {online && open.slice(0, 3).map((r) => (
        <Pressable key={r.id} style={styles.row} onPress={() => accept(r.id)}>
          <Text style={styles.rowTxt}>{r.km} km · {r.price} €</Text>
          <Text style={styles.rowAct}>Accepter</Text>
        </Pressable>
      ))}
      <Btn label={online ? 'Se mettre hors ligne' : 'Se mettre en ligne'} kind={online ? 'ghost' : 'primary'} onPress={toggleOnline} />
    </>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: C.bg },
  tabs: { flexDirection: 'row', margin: 12, borderRadius: 10, backgroundColor: '#E6EBF0', padding: 3 },
  tab: { flex: 1, paddingVertical: 9, borderRadius: 8, alignItems: 'center' },
  tabOn: { backgroundColor: '#fff' },
  tabTxt: { color: '#5B6B7A', fontWeight: '600' },
  tabTxtOn: { color: C.ink },
  map: { flex: 1 },
  sheet: { padding: 18, gap: 10, backgroundColor: '#fff', borderTopWidth: 1, borderColor: C.line },
  title: { fontSize: 18, fontWeight: '700', color: C.ink },
  sub: { color: '#5B6B7A' },
  btn: { backgroundColor: C.accent, paddingVertical: 14, borderRadius: 10, alignItems: 'center' },
  btnGhost: { backgroundColor: 'transparent', borderWidth: 1, borderColor: C.danger },
  btnTxt: { color: '#fff', fontWeight: '700' },
  row: { flexDirection: 'row', justifyContent: 'space-between', paddingVertical: 12, borderBottomWidth: 1, borderColor: C.line },
  rowTxt: { color: C.ink, fontWeight: '600' },
  rowAct: { color: C.accent, fontWeight: '700' },
});
